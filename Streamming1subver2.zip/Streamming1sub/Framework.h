#pragma once
#include "Network.h"

class Framework
{
public:
	Framework(Network * g);
	~Framework();
	virtual double get_solution(int noisetype, double eps, vector<int> costs,bool is_ds=true) ;
	double estimate_influence(const kseeds & seeds,uint k, uint l);
	double estimate_test(const kseeds & seeds, uint n);

protected:
	Network * g;
	uint no_samples;
};

