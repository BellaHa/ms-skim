#include "Greedy.h"

Greedy::Greedy(Network * g) : Framework(g)
{
}

Greedy::~Greedy()
{
}

double Greedy::get_solution(int noisetype, double eps, vector<int> costs,bool is_ds)
{
	vector<uint> seeds;
	int no_nodes = g->get_no_nodes(); // number of nodes of the graph
	vector<bool> selected(no_nodes, false);
	for (int j = 0; j < Constants::BUDGET; ++j) {
		double max = 0;
		int e = 0, i = 0, u = 0;
		for (u = 0; u < no_nodes; ++u) {
			if (!selected[u]) {
			//	for (int ii = 0; ii < Constants::K; ++ii) {
					vector<uint> seeds_tmp = seeds;
					double est_F = estimate_influence(seeds,Constants::k,Constants::l);
					seeds_tmp.push_back(u);
					double est_Fu = estimate_influence(seeds_tmp,Constants::k,Constants::l);
					if(noisetype ==1)//additive
					{
						if(max< 1/costs[u]*(est_Fu/(1-eps)-est_F/(1+eps)))
							{
								max = est_Fu;
								e=u;
							}
					}
					else { //multicative
						if(max<1/costs[u]*(est_Fu-est_F))
							{
								max = est_Fu;
								e=u;
							}
					}
					/*
					if (max < est_F) {
						max = est_F;
						e = u;
						//i = ii;
					}
					*/
				//}
			}
		}

		if (max > 0) {
			seeds.push_back(e);
			selected[e] = true;
		}
		else break;
	}
	return estimate_influence(seeds,Constants::k,Constants::l);
}
