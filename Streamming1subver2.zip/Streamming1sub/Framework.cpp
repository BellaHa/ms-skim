#include "Framework.h"
#include <math.h>
#include "Assert.h"

Framework::Framework(Network * g)
{
	this->g = g;
	no_samples = ceil(6.75 * ((double)(g->get_no_nodes())) / (Constants::EPS * Constants::EPS));
}

Framework::~Framework()
{
}

//double Framework::estimate_influence(const vector<pair<uint, uint>> seeds)
//{
//	double re = 0.0;
//	int n = 100;
//	vector<bool> a(n, false);
//
//	#pragma omp parallel for
//	for (int i = 0; i < n; ++i) {
//		a[i] = (g->sample_influence_linear_threshold(seeds) == 1);
//	}
//
//	for (bool b : a)
//		if (b) re += 1.0;
//
//	return re / n * g->get_no_nodes();
//}

double Framework::estimate_test(const kseeds & seeds, uint n)
{
	double re = 0.0;
	vector<bool> a(n, false);

	#pragma omp parallel for
	for (int i = 0; i < n; ++i) {
		a[i] = (g->sample_influence_linear_threshold(seeds) == 1);
	}

	for (bool b : a)
		if (b) re += 1.0;

	return re / n * g->get_no_nodes();
}

vector<pair<uint, uint>> sourceZ, destZ;
vector<size_t> sourceI, destI;
vector<vector<uint>> sketches;

double Framework::estimate_influence(const kseeds & seeds, uint k, uint l)
{
	
	if (Constants::DATA == Social) {
		sourceI.clear();
		sourceZ.clear();
		const uint sentinelRank = g->get_no_nodes()*l;
		// Collect rank and taus.
		for (const uint s : seeds) {
			const vector<uint> &sketch = sketches[s];
			const size_t num = sketch.size() == k ? sketch.size() - 1 : sketch.size();
			const uint tau = sketch.size() == k ? sketch.back() : (g->get_no_nodes()*l);
			sourceI.push_back(sourceZ.size());
			for (size_t i = 0; i < num; ++i) {
				sourceZ.push_back(make_pair(sketch[i], tau));
			}
			sourceZ.push_back(make_pair(sentinelRank, 0));
		}
		sourceI.push_back(sourceZ.size()); // sentinel

		// Merge while there are things to merge.
		Assert(sourceI.size() >= 2);
		while (sourceI.size() > 2) {
			//cout << " " << sourceZ.size() << flush;
			const size_t num = sourceI.size() - 1;
			for (uint i = 0; i < num; i += 2) {
				destI.push_back(destZ.size());
				const auto beginZ = sourceZ.begin();
				auto first1 = beginZ + sourceI[i];
				auto last1 = beginZ + sourceI[i + 1];

				// In case only one more chunk is left, copy it to destZ.
				if ((i + 1) == num) {
					destZ.insert(destZ.end(), first1, last1);
					continue;
				}

				// Otherwise merge the i'th with the i+1st chunk into destZ.
				Assert((i + 2) < num);
				auto first2 = last1;
				auto last2 = beginZ + sourceI[i + 2];
				while (true) {
					if (first1->first < first2->first) { destZ.push_back(*first1); ++first1; }
					else if (first2->first < first1->first) { destZ.push_back(*first2); ++first2; }
					else if (first1->second > first2->second) { destZ.push_back(*first1); ++first1; ++first2; }
					else { 
						destZ.push_back(*first2); 
						if (first1->first == sentinelRank)
							break;
						++first1; ++first2;
					}
				}
			}
			destI.push_back(destZ.size()); // sentinel

			sourceI.swap(destI);
			sourceZ.swap(destZ);
			destI.clear();
			destZ.clear();
		}

		// Accumulate estimate.
		Assert(!sourceZ.empty());
		sourceZ.pop_back();
		double estimate = 0;
		for (const pair<uint, uint> &z : sourceZ) {
			estimate += 1.0 / double(z.second);
		}
		return estimate*g->get_no_nodes();
	
	/*	double re = 0.0;
		uint need_sample = ceil(((double)no_samples) / seeds.size());
		vector<bool> a(need_sample, false);

		#pragma omp parallel for
		for (int i = 0; i < need_sample; ++i) {
			a[i] = (g->sample_influence_linear_threshold(seeds) == 1);
		}

		for (bool b : a)
			if (b) re += 1.0;

		return re / need_sample * g->get_no_nodes();
		*/
		
	}
	/*
	else {
		return g->get_entropy(seeds);
	}
	*/
}
