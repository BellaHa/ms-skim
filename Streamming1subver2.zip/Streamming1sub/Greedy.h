#pragma once
#include "Framework.h"

class Greedy: public Framework
{
public:
	Greedy(Network * g);
	~Greedy();
	double get_solution(int noisetype, double eps, vector<int> costs,bool is_ds = true);
	
};

