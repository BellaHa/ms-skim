#!/bin/bash
bin/RunSKIM -i test.metis -type metis -k 20 -c 2 -l 64 -N 30 -eps 0.25 -os test3.imstats
