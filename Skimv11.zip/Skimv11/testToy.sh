#!/bin/bash
bin/RunSKIM -i toy.metis -type metis -k 3 -c 2 -l 4 -N 4 -eps 0.25 -os toy.imstats
