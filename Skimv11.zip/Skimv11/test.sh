#!/bin/bash
bin/RunSKIM -i test.metis -type metis -k 20 -c 2 -noise 1 -eps 0.25 -l 64 -N 100 -os testadd.imstats
bin/RunSKIM -i test.metis -type metis -k 20 -c 2 -noise 0 -eps 0.25 -l 64 -N 100 -os testmulti.imstats
