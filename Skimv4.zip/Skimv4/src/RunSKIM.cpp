/*
Algorithm for Influence Estimation and Maximization

Copyright (c) Microsoft Corporation

All rights reserved.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the ""Software""), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
#include <iostream>
#include <string>

using namespace std;

#ifdef __CYGWIN__
#define WINVER 0x0602
#define _WIN32_WINNT 0x0602
#endif

#include "FastStaticGraphs.h"
#include "Multicore.h"
#include "MetisGraphBuilder.h"
#include "DimacsGraphBuilder.h"
#include "CommandLineParser.h"
#include "SKIM.h"
//#include <time.h>
#include <algorithm>

void Usage(const string name) {
	cout << name << " -i <graph> [options]" << endl
		<< endl
		<< "Options:" << endl
		<< " -type <str>  -- type of input from {metis, dimacs, bin} (default: metis)." << endl
		//<< " -cost <str>  -- costfile (txtfile)." << endl
		<< " -undir       -- treat the input as an undirected graph." << endl
		<< " -nopar       -- remove parallel arcs in input." << endl
		<< " -trans       -- transpose the input (reverse graph)." << endl
		<< endl
		<< " -m <string>  -- IC model used (binary, trivalency, weighted; default: weighted)." << endl
		<< " -p <double>  -- probability with which an arc is in the graph (binary model)." << endl
		<< endl
		<< " -noise <int> -- type of noise(0: multiplicative, 1: additive"<<endl
		<< " -eps <double> -- epsilon"
		<< " -c <int>       -- const c(default 3)"
        << " -N <int>     -- size of seed set to compute (default: graph size)." << endl
       // << " -B <int>     -- Budget." << endl
		<< " -k <int>     -- the k-value from the reachability sketches (default: 64)." << endl
		<< " -l <int>     -- number of instances in the ic model (default: 64)." << endl
		<< " -leval <int> -- the number of instances to evaluate exact influence on (0 = off; default)." << endl
		<< endl
		<< " -t <int>     -- number of threads (default: 1)." << endl
		<< " -numa <int>  -- pinned NUMA node to run on (default: any and all)." << endl
		<< " -seed <int>  -- seed for random number generator (default: 31101982)." << endl
		<< " -os <string> -- filename to output statistics to." << endl
		<< " -oc <string> -- filename to output detailed coverage information to." << endl
		<< " -v           -- omit output to console." << endl;
	exit(0);
}

int main(int argc, char **argv) {

	Tools::CommandLineParser clp(argc, argv);

	// Read parameters from the command line.
	const string graphFilename = clp.Value<string>("i");
	const string graphType = clp.Value<string>("type", "metis");
	const string costFile  = clp.Value<string>("cost");

    const uint16_t l = clp.Value<uint16_t>("l", 64); // num of instance

	const uint16_t lEval = clp.Value<uint16_t>("leval", 0);
	const bool verbose = !clp.IsSet("v");
	const uint32_t s = clp.Value<uint32_t>("seed", 31101982);
	const string statsFilename = clp.Value<string>("os");
	const string coverageFilename = clp.Value<string>("oc");
	const int32_t numt = clp.Value<int32_t>("t", 1);

	const string modelStr = clp.Value<string>("m", "weighted");

	if (graphFilename.empty()) Usage(clp.ExecutableName());

	if (clp.IsSet("numa")) {
		cout << "Setting affinity mask of this process to " << Platform::GetAffinityMaskForNumaNode(clp.Value<uint32_t>("numa")) << "... " << flush;
		Platform::PinProcessToNumaNode(clp.Value<uint32_t>("numa"));
		cout << "done." << endl;
	}
   // cout<<"file name:"<<graphFilename<<endl;
	// Load the graph.
	DataStructures::Graphs::FastUnweightedGraph graph;

	if (graphType == "metis")
	{
        	cout<<"file metis name:"<<graphFilename<<endl;
        	RawData::BuildMetisGraph(graphFilename, graph, true, clp.IsSet("trans"), !clp.IsSet("undir"), true, clp.IsSet("nopar"), verbose);
        	cout<<"Build metis done"<<endl;
	}

	else if (graphType == "dimacs")
		RawData::BuildDimacsGraph(graphFilename, graph, true, clp.IsSet("trans"), !clp.IsSet("undir"), true, clp.IsSet("nopar"), verbose);
	else if (graphType == "bin")
		graph.Read(graphFilename, true, verbose);
	else
		Usage(clp.ExecutableName());

	const uint32_t N = clp.Value<uint32_t>("N", 0);
	//const uint32_t B = clp.Value<uint32_t>("B", 0);
	uint32_t n = graph.NumVertices();
	//float e = 2.71828;
    double epsilon = 0.1;
    epsilon = clp.Value<float>("eps",0.1);
    int noisetype = clp.Value("noise",0); // default la nhieu nhan
    int c =3;
    c=clp.Value("c",3);
    uint16_t k;
    if(c<3) k= clp.Value<uint16_t>("k", 64); // k-value
	else{   double kreal=c*log(n);
        kreal =kreal/(epsilon*epsilon); //k = c−2 log(n)
        k = (uint16_t)kreal;
    }
    /*====read cost file*/
    vector<int> cost(n,0);

   // ifstream cFile(costFile);
	float  tmpF = 0;
	//cost[0]=0;
	srand((int)time(0));
    //rand in 1-10
    for (int i = 0; i <n; ++i){
	   //cFile >> tmpF;
        int res = rand() % (10 - 1 + 1) + 1;
       //int res=1;
        cost[i] =res;
       // cout<<cost[i]<<endl;
	}
	cout<<endl;
	//cFile.close();
	int cmax = 10;
	for(int i =0; i<n; i++)
	{
        if(cmax < cost[i]) cmax = cost[i];
        if(cmax >10) cmax =10;
        if(cmax <1) cmax = 1;
	}
   /* ========================*/
   /*=test input*/
   cout<<"graph size:"<<n<<" c:"<<c<<" k:"<<k<<" epsilon:"<<epsilon<<endl;
   //
	// Create the algorithm.
	Algorithms::InfluenceMaximization::SKIM skim(graph, s, verbose,cost,epsilon);
	// Determine IC model and run algorithm.
	if (modelStr == "binary")  {
		skim.SetBinaryProbability(clp.Value<double>("p", 0.1));
		skim.Run<Algorithms::InfluenceMaximization::SKIM::BINARY>(N,cost,epsilon,k, l, lEval, numt, statsFilename, coverageFilename);
		}
	if (modelStr == "trivalency")
		skim.Run<Algorithms::InfluenceMaximization::SKIM::TRIVALENCY>(N,cost,epsilon, k, l, lEval, numt, statsFilename, coverageFilename);
	if (modelStr == "weighted")
		skim.Run<Algorithms::InfluenceMaximization::SKIM::WEIGHTED>(N,cost,epsilon, k, l, lEval, numt, statsFilename, coverageFilename);

	return 0;
}
